package com.example.shop.service;

import com.example.shop.exception.ConflictException;
import com.example.shop.exception.ResourceNotFoundException;
import com.example.shop.model.Customer;
import com.example.shop.repository.CustomerRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class CustomerService {

    private final CustomerRepository customerRepository;

    public CustomerService(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }

    @Transactional
    public Customer register(Customer customer) {
        String email = customer.getEmail().trim();
        if (customerRepository.existsByEmailIgnoreCase(email)) {
            throw new ConflictException("A customer with this email already exists: " + email);
        }
        customer.setId(null);
        customer.setEmail(email);
        customer.setName(customer.getName().trim());
        return customerRepository.save(customer);
    }

    @Transactional(readOnly = true)
    public Customer getById(Long id) {
        return customerRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Customer not found with id " + id));
    }

    @Transactional(readOnly = true)
    public Customer getByEmail(String email) {
        return customerRepository.findByEmailIgnoreCase(email.trim())
                .orElseThrow(() -> new ResourceNotFoundException("No customer with email " + email));
    }
}
