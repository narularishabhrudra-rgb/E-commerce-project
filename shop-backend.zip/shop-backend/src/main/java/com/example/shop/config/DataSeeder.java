package com.example.shop.config;

import com.example.shop.model.Category;
import com.example.shop.model.Product;
import com.example.shop.repository.CategoryRepository;
import com.example.shop.repository.ProductRepository;
import java.math.BigDecimal;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

/** Adds sample data on first start so the demo storefront is not empty. */
@Component
public class DataSeeder implements CommandLineRunner {

    private final CategoryRepository categoryRepository;
    private final ProductRepository productRepository;

    public DataSeeder(CategoryRepository categoryRepository, ProductRepository productRepository) {
        this.categoryRepository = categoryRepository;
        this.productRepository = productRepository;
    }

    @Override
    public void run(String... args) {
        if (categoryRepository.count() > 0) {
            return;
        }
        Category electronics = categoryRepository.save(new Category("Electronics"));
        Category books = categoryRepository.save(new Category("Books"));
        Category fashion = categoryRepository.save(new Category("Fashion"));
        Category home = categoryRepository.save(new Category("Home"));

        productRepository.save(new Product("Wireless Headphones",
                "Over-ear Bluetooth headphones with a 30-hour battery", new BigDecimal("59.99"), 25, electronics));
        productRepository.save(new Product("Smart Watch",
                "Fitness tracking, heart-rate monitor and notifications", new BigDecimal("89.50"), 15, electronics));
        productRepository.save(new Product("Power Bank 20000mAh",
                "Fast-charging portable battery with two USB ports", new BigDecimal("29.00"), 40, electronics));
        productRepository.save(new Product("Clean Code",
                "A handbook of agile software craftsmanship", new BigDecimal("34.90"), 30, books));
        productRepository.save(new Product("Effective Java",
                "Best practices for the Java platform", new BigDecimal("42.00"), 20, books));
        productRepository.save(new Product("Cotton T-Shirt",
                "Soft everyday crew-neck t-shirt", new BigDecimal("12.99"), 60, fashion));
        productRepository.save(new Product("Running Shoes",
                "Lightweight breathable shoes for daily runs", new BigDecimal("64.00"), 18, fashion));
        productRepository.save(new Product("Desk Lamp",
                "Adjustable LED lamp with three brightness levels", new BigDecimal("19.99"), 35, home));
    }
}
