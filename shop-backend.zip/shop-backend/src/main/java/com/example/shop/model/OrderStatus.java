package com.example.shop.model;

public enum OrderStatus {
    PLACED, PAID, SHIPPED, DELIVERED, CANCELLED;

    /** Allowed lifecycle: PLACED -> PAID -> SHIPPED -> DELIVERED, cancellable before shipping. */
    public boolean canMoveTo(OrderStatus next) {
        switch (this) {
            case PLACED:
                return next == PAID || next == CANCELLED;
            case PAID:
                return next == SHIPPED || next == CANCELLED;
            case SHIPPED:
                return next == DELIVERED;
            default:
                return false;
        }
    }
}
