package com.example.shop.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI shopOpenApi() {
        return new OpenAPI().info(new Info()
                .title("E-commerce Backend API")
                .version("1.0.0")
                .description("Products, categories, customers and orders with stock management."));
    }
}
