package com.example.shop.dto;

import com.example.shop.model.OrderStatus;
import jakarta.validation.constraints.NotNull;

public record StatusUpdateRequest(
        @NotNull(message = "Status is required")
        OrderStatus status) {
}
