package com.example.shop.dto;

import com.example.shop.model.Order;
import com.example.shop.model.OrderStatus;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

public record OrderResponse(
        Long id,
        Long customerId,
        String customerName,
        OrderStatus status,
        BigDecimal total,
        LocalDateTime createdAt,
        List<OrderItemResponse> items) {

    public static OrderResponse from(Order o) {
        return new OrderResponse(o.getId(), o.getCustomer().getId(), o.getCustomer().getName(),
                o.getStatus(), o.getTotal(), o.getCreatedAt(),
                o.getItems().stream().map(OrderItemResponse::from).toList());
    }
}
