package com.example.shop.exception;

/** The request is valid but clashes with the current state (duplicate, wrong status, etc.). */
public class ConflictException extends RuntimeException {
    public ConflictException(String message) {
        super(message);
    }
}
