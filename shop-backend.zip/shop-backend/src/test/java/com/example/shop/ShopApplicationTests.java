package com.example.shop;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import com.example.shop.dto.OrderItemRequest;
import com.example.shop.dto.OrderRequest;
import com.example.shop.dto.OrderResponse;
import com.example.shop.exception.InsufficientStockException;
import com.example.shop.model.Customer;
import com.example.shop.model.OrderStatus;
import com.example.shop.service.CustomerService;
import com.example.shop.service.OrderService;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopApplicationTests {

    @Autowired
    private CustomerService customerService;

    @Autowired
    private OrderService orderService;

    private Customer newCustomer(String email) {
        Customer c = new Customer();
        c.setName("Test User");
        c.setEmail(email);
        return customerService.register(c);
    }

    @Test
    void placingAnOrderCalculatesTotal() {
        Customer customer = newCustomer("total@example.com");
        // product 1 is seeded at 59.99
        OrderResponse order = orderService.placeOrder(
                new OrderRequest(customer.getId(), List.of(new OrderItemRequest(1L, 2))));
        assertEquals(0, order.total().compareTo(new java.math.BigDecimal("119.98")));
        assertEquals(OrderStatus.PLACED, order.status());
    }

    @Test
    void orderingMoreThanStockIsRejected() {
        Customer customer = newCustomer("stock@example.com");
        assertThrows(InsufficientStockException.class, () -> orderService.placeOrder(
                new OrderRequest(customer.getId(), List.of(new OrderItemRequest(1L, 100)))));
    }
}
